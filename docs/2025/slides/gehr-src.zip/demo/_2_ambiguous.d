static if(is(typeof(z))) {
	static if(!is(typeof(y))) {
		enum x = 1;
	}
}
static if(!is(typeof(x))) {
	enum y = 2;
}
static if(is(typeof(y))) {
	enum z = 3;
}
