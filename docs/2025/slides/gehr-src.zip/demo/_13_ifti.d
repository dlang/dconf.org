// credit: Steven Schveighoffer

struct S{
	alias T=int;
}

void foo(T)(T s, T.T t){}

void main(){
	S s;
	foo(s,2);
}
