int foo(long z) => 1;
static if(foo(1) == 1) {
    static assert(foo(1) == 1); // fails

    int foo(int x) => 2;
}
