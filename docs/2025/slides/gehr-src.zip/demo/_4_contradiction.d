static if(is(typeof(x))) {
    pragma(msg, "x defined above");
}
static if(!is(typeof(x))) {
    enum x = 2;
}
