static if(is(typeof(x))) {
    enum y = 2;
}
static if(!is(typeof(z))) {
    enum x = 1;
    mixin(`enum k = 0;`);
}
static if(is(typeof(w))) {
    enum z = 3;
}


static if(is(typeof(x))) {
	pragma(msg, "x exists");
}
static if(is(typeof(y))) {
	pragma(msg, "y exists");
}
static if(is(typeof(z))) {
	pragma(msg, "z exists");
}
