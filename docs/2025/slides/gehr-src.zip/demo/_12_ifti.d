
alias Array(T)=T[];

void foo(T)(Array!T x){
	pragma(msg, T);
}

void main(){
	Array!int x;
	foo(x);
}
