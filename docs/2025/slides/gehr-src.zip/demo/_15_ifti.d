
auto compose(A,B,C)(C delegate(B) f, B delegate(A) g){
	pragma(msg, A, " ", B, " ", C);
	return (A x)=>f(g(x));
}

void main(){
	auto dg = compose(y=>2.0*y, (int x)=>x+1.0f);
}
