string foo() => q{static string foo() => q{int bar() => 2;};};

struct S{
    mixin(foo());
}



alias string=typeof("");
