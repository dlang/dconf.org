static if(is(typeof(x))) {
    enum y = true;
}
static if(!is(typeof(z))) {
    enum x = true;
}

static if(is(typeof(x))) {
	pragma(msg, "x exists");
}
static if(is(typeof(y))) {
	pragma(msg, "y exists");
}
static if(is(typeof(z))) {
	pragma(msg, "z exists");
}
