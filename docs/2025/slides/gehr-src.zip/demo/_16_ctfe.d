
int foo(){
	mixin(bar(0));
	return qux();
}

string bar(int x){
	if(x == 0)
		return q{int qux()=>1;};
	if(foo() == 0)
		return q{int qux()=>2;};
	return q{int qux()=>3;};
}

pragma(msg, foo());

alias string=typeof("");
