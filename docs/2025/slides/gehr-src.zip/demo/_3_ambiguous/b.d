import a;
static if(!is(typeof(x))) {
    enum y = 2;
}
