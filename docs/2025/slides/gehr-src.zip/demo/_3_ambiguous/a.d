import b;
static if(!is(typeof(y))) {
    enum x = 1;
}
