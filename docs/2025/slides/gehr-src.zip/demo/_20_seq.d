
alias Seq(T...) = T;

auto foo(int i) {
	Seq!(int, int, int) x = i++;
	return x;
}

int[] bar() {
	int x = 0;
	auto a = [foo(0), foo(1), (++x, Seq!())];
	return a ~ x;
}
pragma(msg, bar());
