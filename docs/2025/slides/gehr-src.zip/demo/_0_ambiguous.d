
static if(!is(typeof(x))) {
	enum y = 2;
}

static if(!is(typeof(y))) {
	enum x = 1;
}
