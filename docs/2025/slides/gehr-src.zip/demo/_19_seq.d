
alias Seq(T...) = T;

auto foo(int i) {
	Seq!(int, int, int) x = i++;
	return x;
}

int[] bar() => [foo(0), foo(1)];
pragma(msg, bar());
