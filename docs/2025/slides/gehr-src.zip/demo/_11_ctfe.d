
alias string=typeof("");
alias size_t=typeof([].length);


size_t balancedIndexOf(alias a=(a,b)=>a==b, T, V...)(const(T)[] c, V v){
	size_t bal1 = 0, bal2 = 0, bal3 = 0, bal4 = 0, bal5 = 0;
	for(size_t i=0;i<c.length;i++){
		if(!bal1&&!bal2&&!bal3&&!bal4&&!bal5&&a(c[i],v)) return i;

		if(c[i]=='"') bal2=!bal2;
		else if(c[i]=='\'') bal1=!bal1;
		else if(!bal2&&!bal1){
			if(c[i]=='(') bal3++;
			else if(c[i]==')') bal3--;
			else if(c[i]=='[') bal4++;
			else if(c[i]==']') bal4--;
			else if(c[i]=='{') bal5++;
			else if(c[i]=='}') bal5--;
		}
	}
	return -1;
}

string[] splitIdent(string str){
	if('0'<=str[0]&&str[0]<='9') return ["",str];
	for(int i=0;i<str.length;i++)
		if(('a'>str[i]||str[i]>'z')&&('A'>str[i]||str[i]>'Z')&&('0'>str[i]||str[i]>'9')&&str[i]!='_')
			return [str[0..i], str[i..$]];
	return [str,""];
}

string trimLeft(string str){
	while(str.length&&(str[0]==' '||str[0]=='\t'||str[0]=='\v'))
		str = str[1..$];
	return str;
}

T[] iota(T)(T a, T b){ T[] r; for(T i=a;i<b;i++) r~=i; return r; }

auto map(alias a,T)(T[] arg) if(is(typeof(a(arg[0])))){
	typeof(a(arg[0]))[] r;
	for(int i=0;i<arg.length;i++)
		r~=a(arg[i]);
	return r;
}
auto filter(alias a,T)(T[] arg) if(is(typeof(cast(bool)a(arg[0])):bool)){
	typeof(arg) r;
	for(int i=0;i<arg.length;i++)
		if(a(arg[i])) r~=arg[i];
	return r;
}
auto join(T,S)(T[] arg, S sep){
	T r;
	for(size_t i=0;i+1<arg.length;i++)
		r~=arg[i]~sep;
	r~=arg[$-1];
	return r;
}

auto toString(int i){
	string s="";
	if(!i) return "0";
	bool n = i<0;
	if(n) i=-i;
	do s=('0'+i%10)~s, i/=10; while(i);
	if(n) s="-"~s;
	return s;
}


template Cont(R,A){ alias R delegate(R delegate(A)) Cont; }

auto ret(R=A,A)(A arg){ return (R delegate(A) k)=>k(arg); }
auto bind(R,A,B)(Cont!(R,A) me, Cont!(R,B) delegate(A) f){
	return (R delegate(B) k)=>me(r=>f(r)(k));
}


Cont!(S,T) arrayToCont(S,T)(T[] a){
	return (S delegate(T) dg){
		S r;
		foreach(x;a) r~=dg(x);
		return r;
	};
}



private string Ximpl(string x){
	string r=`"`;
	foreach(ref i;0..x.length){
	//for(size_t i=0;i<x.length;i++){
		if(x[i]=='@'&&i+1<x.length&&x[i+1]=='('){
			auto start = i+1;
			i+=2;
			auto inc = balancedIndexOf(x[i..$],')');
			assert(~inc, x[i..$]);
			i += inc;
			r~=`"~`~x[start..i+1]~`~"`;
		}else{
			if(x[i]=='"'||x[i]=='\\') r~="\\";
			r~=x[i];
		}
	}
	return r~`"`;
}

template X(string x){
	enum X = Ximpl(x);
}

template compr(string c){
	auto computeCompr(){
		auto c=c;
		c = trimLeft(c);
		auto barp = balancedIndexOf(c,'|');
		assert(barp!=-1,"'|' is missing");
		auto exp = c[0..barp];
		c=trimLeft(c[barp+1..$]);
		string[] idents;
		string[] exprs;
		string[] conditions;
		for(;;){
			auto s = splitIdent(c);
			if(!s[0].length) goto parseCondition;
			//assert(s[0].length, "expected identifier at "~s[1]);
			auto rmd = trimLeft(s[1]);
			if(rmd.length<2 || rmd[0]!='<' || rmd[1]!='-') goto parseCondition;
			c = rmd;
			idents ~= s[0];
			assert(s[0][0]!='_',"leading underscore identifiers are reserved");
			//assert(c[0]=='<' && c[1]=='-', c);
			c=c[2..$];
			auto cp = balancedIndexOf(c,',');
			exprs ~= c[0..~cp?cp:$];
			conditions~="true";
			c = c[exprs[$-1].length..$];
			if(!c.length) break;
			c = trimLeft(c[1..$]);
			continue;
		parseCondition:
			assert(conditions.length>0);
			cp = balancedIndexOf(c,',');
			conditions[$-1]~="&&("~c[0..~cp?cp:$]~")";
			c = c[~cp?cp:$..$];
				
			if(!c.length) break;
			c = trimLeft(c[1..$]);
		}
		string[] types = map!(x=>"typeof(_"~x~"[0])")(idents);
		
		string rtype = "typeof({";
		for(size_t i=0;i<idents.length;i++)
			rtype~=types[i]~" "~idents[i]~";";
		rtype ~= "return "~exp~";}())[]";
		return mixin(X!q{
			(@({string r;
				for(size_t i=0;i<idents.length;i++)
					r~="typeof("~exprs[i]~") _"~idents[i]~", ";
				return r;
			}())){
				alias arrayToCont i; alias @(rtype) R;
				return @({
					string r;
					for(int i=0;i<idents.length;i++)
						r~="bind(i!R(_"~idents[i]~"),"~idents[i]~"=>!("~conditions[i]~")?ret!(R,R)([]):";
					r~="ret!R(["~exp~"])";
					for(int i=0;i<idents.length;i++) r~=')';
					return r;
				}());				
			}(@(join(exprs,',')))
		});
	}
	//pragma(msg, computeCompr());
	enum compr = mixin(computeCompr())(x=>x);
}


pragma(msg, "compr: ", compr!q{ [x|1,y] | x <- [1,2,3], y <- [4,5,6], x==y-4});

pragma(msg, "compr2: ", compr!q{ [x<y,y<x] | x <- [1,2,3], y <- [1,2,3], x!=y });

pragma(msg, "compr3: ", compr!q{ [a,b,c].map!toString.join("o") | a<-[1,2], b<-[2,3], c<-[3,4] });

pragma(msg, "compr4: ", compr!q{ [x,y,z] | x <- [1,2,3], x&1, y <- [1,2,3,4], z <-[1,2,3], x+y+z==7 });
