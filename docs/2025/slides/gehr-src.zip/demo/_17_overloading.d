
enum E{
	A, B
}

enum F{
	B, C
}

void foo(E delegate(E) dg){
	
}

void foo(F delegate(F) dg){
	
}

void main(){
	foo((x){ // A
		static if(is(typeof(typeof(x).A)))
			return x;
	});
	
	foo((x){ // B
		static if(is(typeof(typeof(x).B)))
			return x;
	});
	


	foo((x){ // C
		static if(is(typeof(typeof(x).C)))
			return x;
	});

}
