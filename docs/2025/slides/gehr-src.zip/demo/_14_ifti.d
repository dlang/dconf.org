
T[] iota(T)(T a, T b){ T[] r; for(T i=a;i<b;i++) r~=i; return r; }

auto map(alias a,T)(T[] arg) if(is(typeof(a(arg[0])))){
	typeof(a(arg[0]))[] r;
	for(int i=0;i<arg.length;i++)
		r~=a(arg[i]);
	return r;
}



template Cont(R,A){ alias R delegate(R delegate(A)) Cont; }

auto ret(R=A,A)(A arg){ return (R delegate(A) k)=>k(arg); }
auto bind(R,A,B)(Cont!(R,A) me, Cont!(R,B) delegate(A) f){
	return (R delegate(B) k)=>me(r=>f(r)(k));
}

// ((A -> (B -> R) -> R) -> (A -> R) -> R) -> (A -> R) -> R

auto callCC(R,A,B,T...)(Cont!(R,A) delegate(Cont!(R,B) delegate(A),T) f, T args){
	return (R delegate(A) k)=>f(a=>_=>k(a), args)(k);
}

/+pragma(msg, typeof(&callCC!(R,A,B)));
auto testselfapp(){
	return callCC(&callCC!(),);
}+/

auto testcallCC(){
	auto f(Cont!(int,int) delegate(int) cont, int x){
		return bind(x<3?cont(x):ret!int(1),a=>cont(x+a));
	}
	assert(callCC(&f,1)(x=>x)==1);
	assert(callCC(&f,3)(x=>x)==4);
	return callCC(&f,1)(x=>x)+callCC(&f,3)(x=>x);
	//pragma(msg, typeof(&f));
}
static assert(testcallCC()==5);
pragma(msg, "testcallCC: ", testcallCC());


pragma(msg, "callCC: ",callCC!(int,int,int)(ret=>ret(2))(x=>callCC!(int,int,int)(ret=>ret(x+1))(x=>x)));

auto testcallCC2(){
	auto f(Cont!(int,int) delegate(int) cont, int x){
		return cont(1+x);
	}
	// pragma(msg, typeof(&f));
	auto g(Cont!(int,int) delegate(Cont!(int, int) delegate(int)) arg){
		return callCC(arg);
	}
	assert(g(x=>f(x,3))(x=>x) == 4);

	alias Cont!(int,int) delegate(int) R;
	alias Cont!(int,int) delegate(int) A;
	alias Cont!(int,int) delegate(int) B;

	Cont!(R,A) callCCBack(Cont!(R,B) delegate(A) arg){
		//return callCC(arg);
		//return arg(x=>y=>z=>callCC(&f, x(2)(x=>x)+y(2)(3)(x=>x)+z));
		//return callCC(arg);
		return arg(x=>callCC(&f,x));
	}
	return callCC(&callCCBack)(x=>x)(1337);
/+	auto callCCBack(Cont!(Cont!(int, int) delegate(int),int) delegate(Cont!(Cont!(int, int) delegate(int), int) delegate(Cont!(int, int) delegate(int))) arg){
		//return callCC(arg);
		return arg(x=>y=>z=>callCC(&f, x(2)(x=>x)+y(2)(3)(x=>x)+z));
	}
	return callCC!(int,Cont!(int, int) delegate(int),Cont!(int, int) delegate(int))(&callCCBack);+/

	//return callCC(&f, 4);
	//return callCC(&g, callCC(&f, 2));
}
static assert(testcallCC2()(x=>x)==1338);
pragma(msg, "testcallCC2: ", testcallCC2()(x=>x));

auto testcps()
=>	bind(1.ret, a =>
	bind(2.ret, b =>
	bind(3.ret, c =>
	ret!int(a+b+c))))
	(x=>x);


static assert(testcps()==6);
pragma(msg, "testcps: ", testcps());

Cont!(int,int) factcps(Cont!(int,int) delegate(int) cont, int n){
	return 
		bind!(int,int,int)(n<1 ? cont(1) : ret!int(n-1),
		                  a => cont(callCC!(int,int,int)((x,y)=>factcps(x,y), a)(x=>x)*n));
}

pragma(msg, "factcps: ", map!(a=>callCC!(int,int,int)((x,y)=>factcps(x,y),a)((int x)=>x))(iota(1,10)));
