alias string=typeof("");

auto toString(int i){
	string s="";
	if(!i) return "0";
	bool n = i<0;
	if(n) i=-i;
	do s=('0'+i%10)~s, i/=10; while(i);
	if(n) s="-"~s;
	return s;
}

static foreach(i;0..1000){
	mixin(`enum x`~toString(i)~` = i;`);
	pragma(msg, i);
}
